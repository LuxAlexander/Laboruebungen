#!/bin/bash

INPUT_FILE="$1"
BITRATE="200"
RESOLUTION="352x288"
OUTPUT_CSV="kodierungszeiten.csv"

# x264 Presets
PRESETS=(ultrafast superfast veryfast faster fast medium slow slower veryslow placebo)

# Pruefen, ob Datei mitgegeben
if [ -z "$INPUT_FILE" ]; then
    echo "Fehler: Bitte eine .yuv Datei uebergeben!"
    exit 1
fi

# CSV-Header
echo "Preset,Zeit_Sekunden" > "$OUTPUT_CSV"

# Setzt das Ausgabeformat für 'time' auf reine Sekunden (z.B. 2.614), real
TIMEFORMAT="%R"

for PRESET in "${PRESETS[@]}"; do
    echo "Kodieren mit Preset: $PRESET ..."
    OUTPUT_FILE="output_${PRESET}.264"
    
    # ausführen und die reine Echtzeit in CLEAN_TIME speichern
    CLEAN_TIME=$( { time x264 --bitrate "$BITRATE" --preset "$PRESET" --output "$OUTPUT_FILE" "$INPUT_FILE" --input-res "$RESOLUTION" >/dev/null 2>&1; } 2>&1 )
    
    # In die CSV schreiben
    echo "$PRESET,$CLEAN_TIME" >> "$OUTPUT_CSV"
    echo "Fertig! Reale Zeit: $CLEAN_TIME Sekunden."
    echo
done
